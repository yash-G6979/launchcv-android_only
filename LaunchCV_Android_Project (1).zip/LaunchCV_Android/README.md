# LaunchCV Android — free, offline-first resume builder

LaunchCV is a free Android app prototype built around a local HTML interface inside Android WebView. It does not need an account, backend, analytics, API key, or Internet permission.

## Current features
- Resume and cover-letter builder with live preview
- Education and experience/project sections that can be added or removed
- Three resume styles: Modern, Classic, and Compact
- Automatically saves draft details on the device
- Android Share sheet for sharing resume/cover-letter text
- Print / Save as PDF through Android's system print service
- Reset draft and responsive phone UI
- No ads, payments, or network permissions

## Build the Android APK
1. Install Android Studio and Android SDK Platform 35.
2. Open this `LaunchCV_Android` folder in Android Studio.
3. Allow Gradle sync and install any requested compatible build tools.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Test before sharing
- Create a resume, close/reopen the app, and confirm the draft is restored.
- Try all three templates and PDF output.
- Test Share with messaging/email apps.
- Check long resumes and cover letters across multiple Android versions.

## Important
This is source code for an Android Studio project, not a precompiled APK. It has not been compiled or tested on a physical device in this environment. Before Google Play release, create a signed release build, add a launcher icon/screenshots, test the print flow on real devices, and check current Play Console requirements. Since this app is free, no payment system is included.

## Build without installing Android Studio (GitHub Actions)
1. Create a GitHub repository and upload the contents of this project folder.
2. Open the repository's **Actions** tab and choose **Build LaunchCV APK**.
3. Click **Run workflow** (or push to the main branch).
4. When the run finishes, open it and download the **LaunchCV-debug-apk** artifact.
5. Extract the artifact ZIP to get `app-debug.apk`, then install it on your Android phone.

The generated debug APK is for testing/sideloading, not a signed Google Play release.
